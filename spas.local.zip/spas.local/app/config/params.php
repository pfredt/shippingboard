<?php

  return [
    'adminEmail' => 'admin@example.com',
    'days'       => [
      1 => 'info',
      2 => 'warning',
      3 => 'success',
      4 => 'danger',
      5 => 'brown',
      6 => 'active',
      7 => '',
    ],
    'status' => [
      1 => 'Pending CIA',
      2 => 'OK',
      3 => 'GE Pending',
    ]
  ];
