<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=spas',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];
